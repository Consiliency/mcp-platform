# MCP Platform

<div align="center">

![MCP Platform](https://img.shields.io/badge/version-5.0-blue.svg)
![Status](https://img.shields.io/badge/status-production%20ready-green.svg)
![License](https://img.shields.io/badge/license-MIT-blue.svg)
![Docker](https://img.shields.io/badge/docker-ready-blue.svg)
![Kubernetes](https://img.shields.io/badge/kubernetes-ready-blue.svg)

**The production-ready platform for running Model Context Protocol (MCP) services**

[Quick Start](#-quick-start) • [Documentation](#-documentation) • [Features](#-features) • [Installation](#-installation) • [Contributing](#-contributing)

</div>

## 🚀 Quick Start

Get up and running in under 5 minutes:

### Linux/macOS/WSL
```bash
curl -fsSL https://github.com/your-org/mcp-platform/raw/main/mcp-local-setup/install.sh | bash
```

### Windows PowerShell
```powershell
iwr -useb https://github.com/your-org/mcp-platform/raw/main/mcp-local-setup/install.ps1 | iex
```

### Basic Usage
```bash
mcp start          # Start all services
mcp list           # View available services
mcp health         # Check service health
mcp dashboard      # Open web dashboard
```

## 📚 Documentation

### Getting Started
- **[Quick Start Guide](docs/QUICK_START.md)** - Get running in 5 minutes
- **[Installation Guide](docs/INSTALLATION_GUIDE.md)** - Detailed installation instructions
- **[User Guide](docs/USER_GUIDE.md)** - Complete platform features

### Production Deployment
- **[Production Deployment](docs/PRODUCTION_DEPLOYMENT.md)** - Deploy to production environments
- **[Operations Manual](docs/OPERATIONS_MANUAL.md)** - Day-to-day operations
- **[Security Guide](docs/SECURITY_GUIDE.md)** - Security best practices

### Developer Resources
- **[API Reference](docs/API_REFERENCE.md)** - REST API documentation
- **[SDK Documentation](docs/SDK_USAGE.md)** - Multi-language SDK guide
- **[Configuration Reference](docs/CONFIGURATION_REFERENCE.md)** - All configuration options

**[📖 View All Documentation](docs/INDEX.md)**

## ✨ Features

### 🔐 Enterprise Security
- **JWT & OAuth2 Authentication** - Production-ready auth with token refresh
- **Advanced Rate Limiting** - Redis-based distributed rate limiting
- **Security Middleware** - XSS protection, CORS, input validation
- **TLS/SSL Support** - Automated certificate management

### 🚀 Production Infrastructure
- **Multi-Stage Docker Builds** - Optimized container images
- **Health Monitoring** - Comprehensive health checks and probes
- **Auto-Scaling** - Horizontal pod autoscaling
- **High Availability** - Multi-region deployment support

### 📊 Observability
- **Structured Logging** - Winston with multiple formatters
- **Metrics & Monitoring** - Prometheus exporters and Grafana dashboards
- **Error Tracking** - Sentry integration with sensitive data filtering
- **Distributed Tracing** - Request tracking across services

### 🔧 Developer Experience
- **Service Profiles** - Pre-configured service sets for different workflows
- **Hot Reloading** - Development mode with live updates
- **CLI Tools** - Comprehensive command-line interface
- **Multi-Client Support** - Works with Claude, VS Code, Cursor, and more

### 🏗️ Architecture
- **Microservices** - Modular service architecture
- **Service Mesh Ready** - Istio/Linkerd integration
- **Event-Driven** - Async messaging with Redis/RabbitMQ
- **Database Agnostic** - Support for PostgreSQL, MongoDB, Redis

## 🏛️ Platform Architecture

```
┌─────────────────┐     ┌─────────────────┐     ┌─────────────────┐
│   AI Clients    │     │   AI Clients    │     │   AI Clients    │
│  (Claude Code)  │     │   (VS Code)     │     │   (Cursor)      │
└────────┬────────┘     └────────┬────────┘     └────────┬────────┘
         │                       │                       │
         └───────────────────────┴───────────────────────┘
                                 │
                    ┌────────────▼────────────┐
                    │   Traefik Gateway       │
                    │   (localhost:8080)      │
                    └────────────┬────────────┘
                                 │
         ┌───────────────────────┼───────────────────────┐
         │                       │                       │
    ┌────▼─────┐          ┌─────▼─────┐          ┌─────▼─────┐
    │Filesystem│          │    Git    │          │ Database  │
    │   MCP    │          │    MCP    │          │   MCPs    │
    └──────────┘          └───────────┘          └───────────┘
```

## 📦 Available Services

### Core Services
- **filesystem** - File system operations
- **git** - Git repository management
- **browser** - Web automation with Playwright
- **postgres** - PostgreSQL database access
- **mongodb** - MongoDB operations
- **redis** - Redis cache and pub/sub

### Additional Services
- **slack** - Slack integration
- **github** - GitHub API access
- **google-drive** - Google Drive operations
- **everest** - Knowledge base access
- **memory** - Persistent memory storage
- **sequential-thinking** - Advanced reasoning

## 🛠️ Installation

### Prerequisites
- Docker 20.10+ or Docker Desktop
- 4GB RAM minimum (8GB recommended)
- 10GB free disk space

### Supported Platforms
- ✅ Linux (Ubuntu, Debian, RHEL, Fedora)
- ✅ Windows 10/11 (with WSL2)
- ✅ macOS (Intel & Apple Silicon)
- ✅ Cloud (AWS, GCP, Azure)

### Installation Options

#### 1. Automated Installation (Recommended)
See [Quick Start](#-quick-start) above

#### 2. Manual Installation
```bash
git clone https://github.com/your-org/mcp-platform.git
cd mcp-platform/mcp-local-setup
./install.sh
```

#### 3. Docker Compose
```bash
docker compose up -d
```

#### 4. Kubernetes
```bash
helm install mcp-platform ./helm/mcp-platform
```

## 🔧 Configuration

### Basic Configuration
```yaml
# profiles/default.yml
name: default
services:
  - filesystem
  - git
settings:
  auto_start: true
  log_level: info
```

### Environment Variables
```bash
# .env
MCP_HOME=/opt/mcp-platform
MCP_PROFILE=development
MCP_LOG_LEVEL=debug
JWT_SECRET=your-secret-key
```

See [Configuration Reference](docs/CONFIGURATION_REFERENCE.md) for all options.

## 🚀 Production Deployment

The platform is production-ready with support for:

- **Docker Compose** - Single server deployments
- **Kubernetes** - Enterprise scale with Helm charts
- **AWS** - ECS, EKS, CloudFormation templates
- **Google Cloud** - Cloud Run, GKE deployment
- **Azure** - Container Instances, AKS

See [Production Deployment Guide](docs/PRODUCTION_DEPLOYMENT.md) for detailed instructions.

## 📊 Monitoring & Operations

- **Health Dashboard** - Real-time service health
- **Prometheus Metrics** - Comprehensive metrics
- **Grafana Dashboards** - Pre-built visualizations
- **Log Aggregation** - Centralized logging
- **Alerts** - PagerDuty, Slack, email integration

## 🔒 Security

- **Authentication** - JWT, OAuth2, API keys
- **Authorization** - Role-based access control
- **Encryption** - TLS/SSL, encrypted storage
- **Rate Limiting** - DDoS protection
- **Audit Logging** - Complete audit trail

See [Security Guide](docs/SECURITY_GUIDE.md) for best practices.

## 🤝 Contributing

We welcome contributions! Please see our [Contributing Guide](CONTRIBUTING.md) for details.

### Development Setup
```bash
git clone https://github.com/your-org/mcp-platform.git
cd mcp-platform
npm install
npm run dev
```

### Running Tests
```bash
npm test                 # Unit tests
npm run test:integration # Integration tests
npm run test:e2e        # End-to-end tests
```

## 📈 Project Status

**Current Version**: v5.0 (Phase 6 Complete)

### Completed Phases
- ✅ Phase 1: Foundation & Architecture
- ✅ Phase 2: Developer Experience
- ✅ Phase 3: Integration & Ecosystem
- ✅ Phase 4: Enterprise Features
- ✅ Phase 5: Platform Expansion
- ✅ Phase 6: Production Readiness

See [Roadmap](specs/ROADMAP.md) for future plans.

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- The MCP Protocol team for the specification
- All contributors who helped make this platform production-ready
- The open-source community for invaluable feedback

## 📞 Support

- **Documentation**: [docs/INDEX.md](docs/INDEX.md)
- **Issues**: [GitHub Issues](https://github.com/your-org/mcp-platform/issues)
- **Discussions**: [GitHub Discussions](https://github.com/your-org/mcp-platform/discussions)
- **Discord**: [Join our Discord](https://discord.gg/mcp-platform)
- **Enterprise Support**: enterprise@mcp-platform.io

---

<div align="center">

**[Get Started](docs/QUICK_START.md)** • **[Documentation](docs/INDEX.md)** • **[API Reference](docs/API_REFERENCE.md)**

Made with ❤️ by the MCP Platform Team

</div>